# SmartAppManager

This is a skeleton Android app project with placeholders and a dynamic app selection UI for blocking apps.

## Features

- Dynamic selection of apps to block with checkboxes
- Placeholder services and receivers for further development

## How to build

Open this project in Android Studio and build/run on an Android device or emulator.