package com.yourdomain.smartappmanager

// TODO: Implement FirebaseCommandReceiver logic here
class FirebaseCommandReceiver {
}