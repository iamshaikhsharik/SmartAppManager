package com.yourdomain.smartappmanager

// TODO: Implement DeviceAdminReceiver logic here
class DeviceAdminReceiver {
}